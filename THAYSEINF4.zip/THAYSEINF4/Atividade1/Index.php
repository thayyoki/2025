<?php
    require "Computador.php";

    $meuComputador = new Computador("HP", "Preto", "256 G9", 2280);
    $meuComputador->imprimir();


    $meuComputador-> setMarca("Dell");
    $meuComputador-> setCor("Cinza");
    $meuComputador-> setModelo("Inspiron 15");
    $meuComputador-> setPreco(2700);
    $meuComputador-> imprimir();


    $meuComputador->darDesconto();
    $meuComputador->imprimir();


   



