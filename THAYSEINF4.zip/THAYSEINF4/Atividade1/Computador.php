<?php
    class Computador{
        private $marca;
        private $cor;
        private $modelo;
        private $preco;


    public function __construct($marca, $cor, $modelo, $preco){
        $this->marca = $marca;
        $this->cor = $cor;
        $this->modelo = $modelo;
        $this->preco = $preco;

        }

        // METOFOS GETTERS E SETTERS

        public function getMarca() {
            return $this->marca;
        }

        public function setMarca($marca){
            $this->marca = $marca;
        }

        public function getCor() {
            return $this->cor;
        }

        public function setCor($cor){
            $this->cor = $cor;
        }

        public function getModelo() {
            return $this->modelo;
        }

        public function setModelo($modelo){
            $this->modelo = $modelo;
        }

        public function getPreco() {
            return $this->preco;
        }

        public function setPreco($preco){
            $this->preco;
            if($preco >= 0)
                $this->preco = $preco;
            else{
                echo "<p>O preço não pode ser inferior a 0.";
            }
        }

        public function imprimir(){
            echo "<p>Marca: " . $this->marca;
            echo "<p>Cor: " . $this->cor;
            echo "<p>Modelo: " . $this->modelo;
            echo "<p>Preco: " . $this->preco;
        }

       public function darDesconto(){
        $this->preco *= 0.9;  
    }

}