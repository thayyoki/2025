<?php 
    class Musica{
        // ATRIBUTOS
        private $titulo;
        private $artista;
        private $duracao;
        private $ano;

        // METODOS
        public function __construct($titulo,$artista, $duracao, $ano){
            $this->titulo = $titulo;
            $this->artista = $artista;
            $this->duracao = $duracao;
            $this->setAno($ano);
        }

        public function getTitulo(){
            return $this->titulo;
        }

        public function setTitulo($titulo){
            $this->titulo = $titulo;
        }

        public function getArtista(){
            return $this->artista;
        }

        public function setArtista($artista){
            $this->artista = $artista;
        }

        public function getDuracao(){
            return $this->duracao;
        }

        public function setDuracao($duracao){
            $this->duracao = $duracao;
        }

        public function getAno(){
            return $this->ano;
        }

        public function setAno($ano){
            if($ano >= 2001)
                $this->ano = $ano;
            else{
                echo "<p>Ano de lançamento inválido.";
            }
        }

        public function imprimir(){
            echo "<p>Titulo: " . $this->titulo;
            echo "<p>Artista: " . $this->artista;
            echo "<p>Duração: " . $this->duracao;
            echo "<p>Ano de lançamento: " . $this->ano;
        }

    }
