<?php
    // INCLUIR O ARQUIVO DA CLASSE AMPLIFICADOR
    require "Musica.php";

    // INSTANCIAR UM OBJETO DA CLASSE AMPLIFICADOR
    $minhaMusica = new Musica("Abracadabra", "Dua lipa", "1:20", 2002);

    // INVOCAR O MÉTODO IMPRIMIR DE AMPLIFICADOR

    $minhaMusica->imprimir();

    // MODIFICAR O VALOR DO MODELO DE AMPLIFICAÇÃO

    $minhaMusica->setArtista("Lady Gaga");
    $minhaMusica->imprimir();
    $minhaMusica->setAno(2001);
    $minhaMusica->imprimir();
    $minhaMusica->setAno(2000);







