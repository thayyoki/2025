<?php
    require "Produto.php";
    require "Comprador.php";
    require "Vendedor.php";
    require "Venda.php";

    // INSTANCIAR UM OBJETO 
    $objProduto = new Produto("Celular", 1500);
    $objVendedor = new Vendedor("Goku" , .02);
    $objComprador = new Comprador("Vegeta", 15001.00);

    // INSTANCIAR UM OBJETO DA VENDA
    $objVenda = new Venda($objProduto, $objComprador, $objVendedor);

    // INVOCAR MÉTODO PARA CONCRETIZAR A VENDA
    $objVenda->concretizarVenda();



    