<?php
    class Venda{
        private $p;
        private $c;
        private $v;

        public function __construct( $p, $c, $v){
            $this->p = $p;
            $this->c= $c;
            $this->v= $v;
        }

        public function concretizarVenda(){
            echo "<p> Resumo da venda: ";
            $this->v->vender();
            $this->c->comprar();
            echo "<p>Produto: " . $this->p;
        }
    }
