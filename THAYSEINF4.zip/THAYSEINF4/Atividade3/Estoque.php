<?php
    class Estoque{
        private $nomeProduto;
        private $valor;
        private $quantidade;

        public function __construct($nomeProduto, $valor, $quantidade){
            $this->setNomeProduto($nomeProduto);
            $this->setValor($valor);
            $this->setQuantidade($quantidade);
    
        }

        public function getNomeProduto() {
            return $this->nomeProduto;
        }

        public function setNomeProduto($nomeProduto){
            $this->nomeProduto = $nomeProduto;
        }

        public function getValor() {
            return $this->valor;
        }

        public function setValor($valor){
            $this->valor = $valor;
        }

        public function getQuantidade() {
            return $this->quantidade;
        }

        public function setQuantidade($quantidade){
            $this->quantidade;
            if($quantidade >= 0)
                $this->quantidade = $quantidade;
            else{
                echo "<p>O Estoque não pode ser inferior a 0.";
            }
        }


        public function retirar($quantidade) {
            if ($quantidade > 0 and $quantidade <= $this->quantidade) {
                $this->quantidade -= $quantidade;
                echo "<p>Quantidade de produtos removidos: " . $quantidade;
                echo "<p>Estoque atualizado: " . $this->quantidade . " unidades.";
            }
            else {
                echo "<p>Não foi possível retirar. Quantidade insuficiente ou inválida";
            }
        }

        public function imprimir(){
            echo "<p>Nome do Produto: " . $this->nomeProduto;
            echo "<p>Valor: " . $this->valor;
            echo "<p>Quantidade: " . $this->quantidade;
        }

        





    }