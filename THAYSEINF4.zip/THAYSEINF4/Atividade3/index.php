<?php
    require "Estoque.php";

$nome = "Camiseta";
$valor = 34;
$quantidade = 65;
$retirar = 28;

$meuEstoque = new Estoque($nome, $valor,  $quantidade);

$meuEstoque->imprimir();

$meuEstoque->retirar($retirar);


