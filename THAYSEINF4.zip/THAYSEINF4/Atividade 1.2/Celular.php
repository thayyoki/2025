<?php
    class Celular {
        // Atributos 
        public $marca;
        public $modelo;
        public $bateria;
        
        // Metodos
        public function ligar(){
            $this->bateria >=1;
            echo "<p>O celular está ligado";
        }

        public function verificarBateria(){
            echo "<p>O nível atual da bateria é: " .  $this->bateria;
        }

    }