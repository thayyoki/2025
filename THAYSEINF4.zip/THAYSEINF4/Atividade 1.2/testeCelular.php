<?php
    // Incluir o arquivo da classe
    require "Celular.php";

    // Instanciar um objeto de ContaCorrente
    $meuCelular = new Celular();

    // Definir os valores dos atributos da conta
    $meuCelular->marca = "Samsung";
    $meuCelular->modelo = "s23";
    $meuCelular->bateria = 81;

    // Exibir o saldo atual da conta
    $meuCelular->ligar();

    // Efetuar um saque
    $meuCelular->verificarBateria();