<?php
    require "Horario.php";

    $meuHorario = new Horario(23,58,20);

    echo $meuHorario;

    for($cont=1; $cont<=1000; $cont++) {
        $meuHorario->tick();
        echo $meuHorario;
    }