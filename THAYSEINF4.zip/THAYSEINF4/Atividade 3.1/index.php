<?php
    require 'livro.php';

    // intanciano um objeto
    $meuLivro = new Livro("O retrato de Dorian Gray", "Oscar Wilde", "Biblioteca Azul", 2013);

    // INVOCAR O MÉTODO
    $meuLivro->Imprimir();


