<?php
    class Livro{
        private $titulo;
        private $autor;
        private $edicao;
        private $ano;

        // METODO CONSTRUTOR
        public function __construct($titulo, $autor, $edicao, $ano){
            $this->titulo = $titulo;
            $this->autor = $autor;
            $this->edicao = $edicao;
            $this->ano = $ano;

        }

        // METOFOS GETTERS E SETTERS

        public function getTitulo() {
            return $this->titulo;
        }

        public function setTitulo($titulo){
            $this->titulo;
        }

        public function getAutor() {
            return $this->autor;
        }

        public function setAutor($autor){
            $this->autor;
        }

        public function getEdicao() {
            return $this->edicao;
        }

        public function setEdicao($edicao){
            $this->edicao;
        }

        public function getAno() {
            return $this->ano;
        }

        public function setAno($ano){
            $this->ano = $ano;
        }

        // METODO IMPRIMIR
        public function imprimir(){
            echo "<p>Título:  "  .  $this->titulo;
            echo "<p>Autor:  "  .  $this->autor;
            echo "<p>Edição:  "  .  $this->edicao;
            echo "<p>Ano:  "  .  $this->ano;
        }
    }