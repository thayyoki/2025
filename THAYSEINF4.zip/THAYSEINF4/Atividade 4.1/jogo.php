<?php
    Class Jogo{
        private $atributos= array("titulo", "plataforma", "valor");
        public function __construct($titulo, $plataforma, $valor){
            $this->atributos["titulo"]=$titulo;
            $this->atributos["plataforma"]=$plataforma;
            $this->atributos["valor"]=$valor;
        }

        public function __get($nome){
            return $this-> atributos[$nome];
        }

        public function __set($nome, $valor){
            $this-> atributos[$nome] = $valor;
        }

        public function imprimir(){
            echo "<p>Titulo: " . $this->atributos["titulo"];
            echo "<p>Plataforma: " . $this->atributos["plataforma"];
            echo "<p>Valor: " . $this->atributos["valor"];
        }
    }