<?php
   // INCLUIR O ARQEUIVO DA CLASSE
    require 'funcionario.php';

    // intanciano um objeto de data
    $meuFuncionario = new Funcionario();

    // DEFINIR OS ATRIBUTOS DA DATA
    $meuFuncionario->setNome('Thayse');
    $meuFuncionario->setIdade(0);
    $meuFuncionario->setCargo('Gerente');
    $meuFuncionario->setSalario(10000);
    $meuFuncionario->aumentarSalario(5);

    // MOSTRAR A DATA
    $meuFuncionario->exibirInformacoes();

