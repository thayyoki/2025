<?php
    class Funcionario{
        // ATRIBUTOS
        private $nome;
        private $idade;
        private $cargo;
        private $salario;

         // METODOS DE ENCAPSULAMENTO
        public function getNome(){
            return $this->nome;
        }

        public function setNome($nome){
            $this->nome =$nome;
        }



        public function getIdade(){
            return $this->idade;
        }

        public function setIdade($idade){
            if($idade>=1)
                $this->idade =$idade;
            else{
                echo"<p>Idade inválida.";
            }
        }



        public function getCargo(){
            return $this->cargo;
        }

        public function setCargo($cargo){
            $this->cargo =$cargo;
        }



        public function getSalario(){
            return $this->salario;
        }  

        public function setSalario($salario){
            $this->salario = $salario;
        }

        
        public function aumentarSalario($percentual){
            $this->salario += $this->salario*$percentual/100;
        }

        // METODO PARA EXIBIR A DATA
        public function exibirInformacoes(){
            echo "<p> " . $this->nome;
            echo "<p> " . $this->idade;
            echo "<p> " . $this->cargo;
            echo "<p> " . $this->salario;

        }

    }