<?php
    class Carro{
        private $marca;
        private $modelo;
        private $anoFabricacao;

        // METODO CONSTRUTOR
        public function __construct($marca, $modelo, $ano){
            $this->marca = $marca;
            $this->modelo = $modelo;
            $this->anoFabricacao = $ano;

        }

        // METOFOS GETTERS E SETTERS

        public function getMarca() {
            return $this->marca;
        }

        public function setMarca($marca){
            $this->marca;
        }

        public function getModelo() {
            return $this->modelo;
        }

        public function setModelo($modelo){
            $this->modelo;
        }

        public function getAnoFabricacao() {
            return $this->anoFabricacao;
        }

        public function setAnoFabricacao($ano){
            $this->anoFabricacao = $ano;
        }

        // METODO IMPRIMIR
        public function imprimir(){
            echo "<p>Marca:  "  .  $this->marca;
            echo "<p>Modelo:  "  .  $this->modelo;
            echo "<p>Ano de fabricação:  "  .  $this->anoFabricacao;
        }
    }