<?php
    require 'hd.php';

    // intanciano um objeto
    $meuHd = new Hd("Seagate", "ST4000DM004", 4);

    // INVOCAR O MÉTODO
    $meuHd->Imprimir();


    $meuHd -> setCapacidade(460);

    $meuHd -> imprimir();



