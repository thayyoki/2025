<?php
    class Hd{
        private $marca;
        private $modelo;
        private $capacidade;

        // METODO CONSTRUTOR
        public function __construct($marca, $modelo, $capacidade){
            $this->marca = $marca;
            $this->modelo = $modelo;
            $this->capacidade = $capacidade;

        }

        // METOFOS GETTERS E SETTERS

        public function getMarca() {
            return $this->marca;
        }

        public function setMarca($marca){
            $this->marca;
        }

        public function getModelo() {
            return $this->modelo;
        }

        public function setModelo($modelo){
            $this->modelo;
        }

        public function getCapacidade() {
            return $this->capacidade;
        }

        public function setCapacidade($capacidade){
            $this->capacidade = $capacidade;
        }

        // METODO IMPRIMIR
        public function imprimir(){
            echo "<p>Marca:  "  .  $this->marca;
            echo "<p>Modelo:  "  .  $this->modelo;
            echo "<p>Capacidade:  "  .  $this->capacidade;
        }
    }